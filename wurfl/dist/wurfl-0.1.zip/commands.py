# Here you can create play commands that are specific to the module, and extend existing commands

MODULE = 'wurfl'

# Commands that are specific to your module

COMMANDS = ['wurfl:install']

def execute(**kargs):
    command = kargs.get("command")
    app = kargs.get("app")
    args = kargs.get("args")
    env = kargs.get("env")

    if command == "wurfl:install":
        print "~ Hello"

def install(**kargs):
    import urllib
    import gzip
    import StringIO
    
    zip_file = urllib.urlopen('http://downloads.sourceforge.net/project/wurfl/WURFL/latest/wurfl-latest.zip').read()
	print zip_file
		
# This will be executed before any command (new, run...)
def before(**kargs):
    command = kargs.get("command")
    app = kargs.get("app")
    args = kargs.get("args")
    env = kargs.get("env")


# This will be executed after any command (new, run...)
def after(**kargs):
    command = kargs.get("command")
    app = kargs.get("app")
    args = kargs.get("args")
    env = kargs.get("env")

    if command == "new":
        pass
